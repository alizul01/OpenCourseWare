/** kelas Person digunakan untuk menyimpan informasi
    setiap orang pada piramida manusia
*/
public class Person {
  
}
