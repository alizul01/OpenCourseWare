package com.example.latihan;

import java.util.Arrays;
import java.util.List;

// difference between for, while, and do-while loops (beside the syntax)
public class ForWhileDoWhile {

	public static void main(String[] args) {
		
		// for loop: especially useful for iterating collection
		System.out.println("FOR-LOOP");
		for(int i = 0; i < 10; i++) {
			System.out.println(i);
		}
		List<String> strs = Arrays.asList("Alpha", "Beta", "Charlie", "Delta");
		for(String str:strs) {
			System.out.println(str);
		}

		// while loop: statements inside loop can be skipped depending on loop condition
		System.out.println("WHILE-LOOP");
		int i = 0;
		while(i > 0) {
			System.out.println(i);
		}
		
		// do-while loop: statements inside loop are executed at least once
		System.out.println("DO-WHILE-LOOP");
		int j = 0;
		do {
			System.out.println(j);
		} while(j > 0);
	}

}
