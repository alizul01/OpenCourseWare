package com.example.latihan;

import java.util.List;

public class Panda {

	static String latinName = "Ailuropoda melanoleuca";
	static String favName = "Bamboo";
	
	String name;
	int age;
	String sex;
	int height;
	int weight;
	
	List<Panda> children;
	
	Panda(String name, int age, String sex, int height, int weight) {
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.height = height;
		this.weight = weight;
	}
	
	public List<Panda> getChildren() {
		return children;
	}

	public void setChildren(List<Panda> children) {
		this.children = children;
	}
	
	public static String getLatinName() {
		return latinName;
	}

	public static void setLatinName(String latinName) {
		Panda.latinName = latinName;
	}

	public static String getFavName() {
		return favName;
	}

	public static void setFavName(String favName) {
		Panda.favName = favName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String toString() {
		return name + ", " + sex + ", " + age;
	}
	
	public boolean equals(Object p2) {
		if(p2 instanceof Panda)
			return this.name.equals(((Panda) p2).getName());
		else
			return false;
	}
	
	public static void main(String[] args) {
		
		Panda po = new Panda("Po", 5, "M", 2, 100);
		Panda anotherPo = new Panda("Po", 5, "Male", 2, 100);
		System.out.println(Panda.latinName);
		System.out.println(po);
		System.out.println(po.equals(anotherPo));

	}

}
