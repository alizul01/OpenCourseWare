package com.example.latihan;

public class FacRecLogicError {

	public static void main(String[] args) {
		
		System.out.println(hitungFaktorialErr(4));
		System.out.println(hitungFaktorial(4));

	}

	// logic error
	public static int hitungFaktorialErr(int n) {
		
		int x = 1;
		do {
			n--;
			if(n == 0)
				break;
			x = x * n;
		} while(n >= 1);
		return x;

	}
	
	// correct version
	public static int hitungFaktorial(int n) {
		
		int x = 1;
		do {
			if(n == 0)
				break;
			x = x * n;
			n--;
		} while(n >= 1);
		return x;

	}
	
}
