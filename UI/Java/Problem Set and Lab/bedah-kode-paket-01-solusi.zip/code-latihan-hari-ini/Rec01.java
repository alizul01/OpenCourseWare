package com.example.latihan;

// recursion
public class Rec01 {

	public static void main(String[] args) {
		
		System.out.println(f(4));  // return 3
		System.out.println(f(10)); // return 9*7*5*3

	}

	public static int f(int x) {
		
		return g(x, 1);
		
	}

	// start multiplication from n to 1, skipping even number
	public static int g(int x, int y) {
		
		if(x <= 0) {
			return 0;
		}

		if(x == 1)
			return y;
		else if(x % 2 == 1) // consider only odd number
			return g(x-1, y * x);
		else // skip even number
			return g(x-1, y);
		
	}
	
}
