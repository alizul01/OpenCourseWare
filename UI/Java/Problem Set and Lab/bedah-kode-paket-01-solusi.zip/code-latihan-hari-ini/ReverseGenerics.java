package com.example.latihan;

import java.util.ArrayList;

public class ReverseGenerics {

	public static void main(String[] args) {
		
		ArrayList<Integer> x = new ArrayList<>();
		x.add(8);
		x.add(1);
		x.add(6);
		x.add(-5);
		x.add(100);
		x.add(1000);
		System.out.println(balik(x));
		
		ArrayList<String> y = new ArrayList<>();
		y.add("A");
		y.add("B");
		y.add("C");
		System.out.println(balik(y));
		
	}
	
	public static <T> ArrayList<T> balik(ArrayList<T> x) {
		
		ArrayList<T> y = new ArrayList<T>();
		for(int i = x.size()-1; i >= 0; i--) {
			y.add(x.get(i)); // add into y from last element of x to first element of x
		}
		return y;
		
	}

}
