package com.example.latihan;

import java.util.ArrayList;

public class EvenOrMoreThan99 {

	public static void main(String[] args) {
		
		ArrayList<Integer> x = new ArrayList<>();
		x.add(8);
		x.add(1);
		x.add(6);
		x.add(-5);
		x.add(100);
		x.add(1000);
		System.out.println(hitungFrek(x));
		
	}

	public static int hitungFrek(ArrayList<Integer> x) {
		
		int frek = 0;
		for(int e:x) {
			if((e % 2 == 0) || (e > 99))
				frek++;
		}
		return frek;
		
	}

}
